// Copyright Epic Games, Inc. All Rights Reserved.

#include "ThirdPerson_Function.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ThirdPerson_Function, "ThirdPerson_Function" );
 