SK_Mannequin T Pose

https://mocaponline.com/blogs/news/a-pose-or-t-pose-conversion-ue4-retarget-manager

This "SK_Mannequin.fbx" has a zeroed out T-Pose like the old 4.7 UE4 Template rig.
(The new 4.8 rig by default is posed in an "A" with the arms/hands rotated on all axes)

It can overwrite (be merged) into any current UE4 Project SK_Mannequin mesh to create a stock T-Pose for use in the Retargeting Manager.

**Note: The hands are rotated up and forward 10 degrees to make a better Tee, their rotation values are not true zero.