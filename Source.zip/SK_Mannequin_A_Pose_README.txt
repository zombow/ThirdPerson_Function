SK_Mannequin A Pose


Our newer packs have the "SK_Mannequin" in a zeroed out T-Pose like the old 4.7 UE4 Template rig. This was done by popular request.
**Note: The hands are rotated up and forward 10 degrees to make a better Tee, their rotation values are not true zero.


If you prefer the new 4.8+ rig default "A" pose with the arms/hands non-zero rotated down on all axes, this "SK_Mannequin.fbx" can overwrite (be merged) into any current UE4 Project SK_Mannequin mesh to create the new stock A-Pose for use in the Retargeting Manager.

